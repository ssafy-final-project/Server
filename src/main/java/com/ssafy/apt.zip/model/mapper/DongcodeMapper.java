package com.ssafy.apt.model.mapper;

import java.sql.SQLException;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DongcodeMapper {
  String findDongcodeByAddress(String address) throws SQLException;
}
