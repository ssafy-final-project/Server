package com.ssafy.apt.model.service;

import java.sql.SQLException;

public interface DongcodeService {
  String findDongcodeByAddress(String address) throws SQLException;
}
