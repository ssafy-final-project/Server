package com.ssafy.apt.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ssafy.apt.model.AptStatDto;
import com.ssafy.apt.model.DongStatDto;
import com.ssafy.apt.model.GugunStatDto;
import com.ssafy.apt.model.service.AptDealService;
import com.ssafy.apt.model.service.StatService;

@RestController
@RequestMapping("/stat")
public class StatController {

  private final StatService statService;

  public StatController(StatService statService) {
    this.statService = statService;
  }

  @GetMapping("/gugun")
  public ResponseEntity<List<GugunStatDto>> getGugunAll() throws Exception {
      return ResponseEntity.ok(statService.getGugunAll());
  }
  
  @GetMapping("/dong")
  public ResponseEntity<List<DongStatDto>> getDongStatAll() throws Exception {
      return ResponseEntity.ok(statService.getDongStatAll());
  }
  
  @GetMapping("/dong/{shortDongcode}")
  public ResponseEntity<List<DongStatDto>> getDongStatByGugun(@PathVariable String shortDongcode) throws Exception {
      return ResponseEntity.ok(statService.getDongStatByGugun(shortDongcode));
  }
  
  @GetMapping("/apt/{shortDongcode}")
  public ResponseEntity<List<AptStatDto>> getAptStatByDong(@PathVariable String shortDongcode) throws Exception {
      return ResponseEntity.ok(statService.getAptStatByDong(shortDongcode));
  }

}
